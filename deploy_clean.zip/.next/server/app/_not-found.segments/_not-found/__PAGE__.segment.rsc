1:"$Sreact.fragment"
2:"/_next/static/chunks/3qfy96eoyh-ek.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
b:I[97367,["$2"],"OutletBoundary"]
c:"$Sreact.suspense"
f:"ViewportBoundary"
10:I[97367,["$2"],"$f"]
11:"MetadataBoundary"
12:I[97367,["$2"],"$11"]
:HL["/_next/static/chunks/2lxfloqgly94i.css","style"]
:HL["/_next/static/chunks/1utgji4i-zaz6.css","style"]
6:X
9:X
9:C
a:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","html",null,{"lang":"fr","className":"GYCy1G_variable Mgzl3q_variable","children":["$","body",null,{"children":["$","main",null,{"className":"wrap flex min-h-dvh flex-col items-start justify-center py-24","children":[["$","p",null,{"className":"kicker","children":"Erreur 404"}],["$","h1",null,{"className":"h-section mt-4","children":"Cette page n’existe pas."}],["$","a",null,{"href":"/","className":"btn mt-10","children":"Retour à l’accueil"}]]}]}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1utgji4i-zaz6.css","precedence":"next"}]],["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]]}],"p":"$@e","v":null,"s":"$6"}}]]
7:[["children",{"s":"/_not-found","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@8","v":"$9","s":"$6"},"c":"$Qa"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2lxfloqgly94i.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/3qfy96eoyh-ek.js","async":true}]],["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","html",null,{"lang":"fr","className":"GYCy1G_variable Mgzl3q_variable","children":["$","body",null,{"children":["$","main",null,{"className":"wrap flex min-h-dvh flex-col items-start justify-center py-24","children":[["$","p",null,{"className":"kicker","children":"Erreur 404"}],["$","h1",null,{"className":"h-section mt-4","children":"Cette page n’existe pas."}],["$","a",null,{"href":"/","className":"btn mt-10","children":"Retour à l’accueil"}]]}]}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1utgji4i-zaz6.css","precedence":"next"}]]]}]]}],"p":"$@5","v":null,"s":"$6"},"c":"$Q7"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L10",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L12",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$c",null,{"name":"Next.Metadata","children":[]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@13","v":null,"s":"$6"}},"a":"$@14","u":"$@15","b":"jpoHWgFtu2bG0W1GTxiut"}
d:null
6:300
15:true
6:C
14:0
8:"$undefined"
5:"$undefined"
13:"$undefined"
e:"$undefined"
