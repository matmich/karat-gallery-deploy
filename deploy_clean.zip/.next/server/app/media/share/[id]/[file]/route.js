var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/media/share/[id]/[file]/route.js")
R.c("server/chunks/[externals]__1m8vax3bqhh12._.js")
R.c("server/chunks/lib_store_ts_1k9hggqek-m7i._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0-b6av8bbd41a._.js")
R.c("server/chunks/_next-internal_server_app_media_share_[id]_[file]_route_actions_0jaur5h2rlndz.js")
R.m(85319)
module.exports=R.m(85319).exports
