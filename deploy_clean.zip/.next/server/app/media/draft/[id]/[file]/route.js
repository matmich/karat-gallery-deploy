var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/media/draft/[id]/[file]/route.js")
R.c("server/chunks/[externals]__1m8vax3bqhh12._.js")
R.c("server/chunks/lib_store_ts_1k9hggqek-m7i._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_14vpcdj22q4lv._.js")
R.c("server/chunks/_next-internal_server_app_media_draft_[id]_[file]_route_actions_04ik_4_xfvndc.js")
R.m(62628)
module.exports=R.m(62628).exports
