module.exports=[10872,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_share_%5Bid%5D_owner_route_actions_218jkts34zchc.js.map