module.exports=[69449,e=>{"use strict";e.s(["register",0,function(){let e=process.env.HOSTNAME??"";(/^127\./.test(e)||"::1"===e||"[::1]"===e)&&console.error(`
[karat] ATTENTION — HOSTNAME=${e} : les pages fran\xe7aises vont tourner en boucle de redirection.
[karat] D\xe9marrez le serveur avec HOSTNAME=0.0.0.0 (ou localhost).
`)}])}];

//# sourceMappingURL=instrumentation_ts_1oq3o45biku4v._.js.map