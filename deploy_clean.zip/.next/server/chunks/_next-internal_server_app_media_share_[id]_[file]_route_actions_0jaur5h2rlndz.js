module.exports=[82200,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_media_share_%5Bid%5D_%5Bfile%5D_route_actions_0jaur5h2rlndz.js.map