module.exports=[63816,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_media_gallery_%5Bid%5D_%5Bslot%5D_route_actions_0vglm534ags4q.js.map