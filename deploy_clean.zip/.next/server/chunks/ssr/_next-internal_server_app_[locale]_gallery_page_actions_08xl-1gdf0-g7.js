module.exports=[25391,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_gallery_page_actions_08xl-1gdf0-g7.js.map