module.exports=[8002,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_atelier_page_actions_0z2t14l4i-dr3.js.map