module.exports=[60906,a=>{"use strict";var b=a.i(66274);a.S([b,"607f32868ab4b9d6821c366c160c9ffa3933194199,N"],60906)}];

//# sourceMappingURL=_next-internal_server_app_admin_login_page_actions_0nzxdyyl-1g8z.js.map