module.exports=[48140,a=>{"use strict";var b=a.i(87924);a.s(["default",0,function({message:a,className:c,children:d}){return(0,b.jsx)("button",{type:"submit",className:c,onClick:b=>{window.confirm(a)||b.preventDefault()},children:d})}])}];

//# sourceMappingURL=components_admin_ConfirmButton_tsx_0fbz0h27bkwq0._.js.map