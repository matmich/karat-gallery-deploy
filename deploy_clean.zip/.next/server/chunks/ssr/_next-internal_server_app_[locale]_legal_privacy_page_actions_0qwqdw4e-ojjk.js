module.exports=[71319,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_legal_privacy_page_actions_0qwqdw4e-ojjk.js.map