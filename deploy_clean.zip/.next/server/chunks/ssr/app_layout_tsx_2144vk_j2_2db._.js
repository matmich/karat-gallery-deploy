module.exports=[33290,a=>{"use strict";a.s(["default",0,function({children:a}){return a}])},70864,function(a){a.n(a.i(33290))}];

//# sourceMappingURL=app_layout_tsx_2144vk_j2_2db._.js.map