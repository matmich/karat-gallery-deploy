module.exports=[21945,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_piece_%5Bid%5D_page_actions_10gp94s1ew16o.js.map