module.exports=[35387,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_legal_imprint_page_actions_0612gy76yn_l3.js.map