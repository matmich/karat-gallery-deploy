module.exports=[61541,a=>{"use strict";let b={name:"Karat Atelier",url:(process.env.SITE_URL||"https://karat-atelier.ch").replace(/\/+$/,""),email:"contact@karat-atelier.ch",legal:{company:"",address:"",uid:"",publisher:""},host:"Infomaniak Network SA, Rue Eugène-Marziano 25, 1227 Les Acacias, Suisse",replyHours:24};a.s(["f",0,b])}];

//# sourceMappingURL=lib_site_ts_1ewtz6iccxv-a._.js.map