module.exports=[85702,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_media_draft_%5Bid%5D_%5Bfile%5D_route_actions_04ik_4_xfvndc.js.map