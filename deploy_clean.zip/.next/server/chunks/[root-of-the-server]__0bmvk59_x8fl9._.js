module.exports=[12714,(e,r,s)=>{r.exports=e.x("node:fs/promises",()=>require("node:fs/promises"))},50227,(e,r,s)=>{r.exports=e.x("node:path",()=>require("node:path"))},82438,e=>{"use strict";var r=e.i(12714),s=e.i(50227);async function o(){{let e=s.default.join(process.cwd(),".next","server","route-cache");await (0,r.rm)(e,{recursive:!0,force:!0}).catch(e=>{console.error("[karat] Le cache des pages fixes n'a pas pu être vidé :",e instanceof Error?e.message:e)})}let e=process.env.HOSTNAME??"";(/^127\./.test(e)||"::1"===e||"[::1]"===e)&&console.error(`
[karat] ATTENTION — HOSTNAME=${e} : les pages fran\xe7aises vont tourner en boucle de redirection.
[karat] D\xe9marrez le serveur avec HOSTNAME=0.0.0.0 (ou localhost).
`)}e.s(["startupChecks",0,o])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0bmvk59_x8fl9._.js.map