module.exports=[93715,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_share_%5Bid%5D_respond_route_actions_0rbf_myjv_9fm.js.map