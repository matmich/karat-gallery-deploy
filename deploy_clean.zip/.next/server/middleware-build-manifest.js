globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/85xHHReKgDqVsR8vDxyDV/_buildManifest.js",
    "static/85xHHReKgDqVsR8vDxyDV/_ssgManifest.js",
    "static/85xHHReKgDqVsR8vDxyDV/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/1wnov70f88xjy.js",
    "static/chunks/0yhbt_2nzx8r2.js",
    "static/chunks/39_j1bdzreq0m.js",
    "static/chunks/2hqfk_jgesiw2.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/[...rest]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/atelier/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/contact/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/gallery/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/legal/imprint/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/legal/privacy/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/piece/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/s/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[locale]/studio/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/gallery/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/gallery/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/leads/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/shares/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/0yhbt_2nzx8r2.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/2hqfk_jgesiw2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
