var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__069rv1gwd69_h._.js")
R.c("server/chunks/[root-of-the-server]__022dfv_tqtnxc._.js")
R.m(62395)
module.exports=R.m(62395).exports
