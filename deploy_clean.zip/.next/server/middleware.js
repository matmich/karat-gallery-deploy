var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0bdc7yti740pw._.js")
R.c("server/chunks/[root-of-the-server]__022dfv_tqtnxc._.js")
R.m(62395)
module.exports=R.m(62395).exports
